# CommandLogger

Allows to log different command which are specified in configuration file.

#### How to use

Specify commands in confifuration file and start the plugin.

#### Predefined commands

| Command | Aliases (separated by ,) |
| - | - |
| /god | |
| /vanish | |
| /investigate | |
| /item | /i, /give |
| /vehicle | /v |
| /teleport | /tp, /tphere |
| /spy | |
| /ban | |
| /kick | |
| /kill | /slay |

#### Pull request by Wisser Tg. My discord: Wisser Tg#3446