﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CommandLogger")]
[assembly: AssemblyCompany("CommandLogger")]
[assembly: AssemblyProduct("CommandLogger")]
[assembly: AssemblyCopyright("CommandLogger")]
[assembly: ComVisible(false)]
[assembly: Guid("34ca52ac-333c-45df-8a77-8c8f7c463faa")]
[assembly: AssemblyVersion("4.2.0")]
[assembly: AssemblyDescription("Made by:  Coolpuppy24")]

