# Zamirathe_HomeCommand
Home Command Rocket Plugin for Unturned 3.0

Added functionality to Rocket's home command.  Adds movement and wait time restrictions.
